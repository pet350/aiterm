// Part of project: aiterm
// terminal.h
// C Program header file for terminal functions
// By: Peter Talbott
// With assistance from Gemini and OpenAI
// April, May 2026

#ifndef TERMINAL_H
#define TERMINAL_H

#include <vte/vte.h>

// Forward declaration: tells the compiler AppContext exists
// without needing the full definition from gui.h yet.
//typedef struct AppContext AppContext;

GtkWidget* setup_terminal(AppContext *app);
void on_vte_child_exited(VteTerminal *vte, gint status, gpointer user_data);
void apply_terminal_transparency(AppContext *app);
void apply_visual_settings(AppContext *app);
char *terminal_capture_context(AppContext *app);

#endif

