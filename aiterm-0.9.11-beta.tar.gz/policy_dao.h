// Part of project: aiterm
// policy_dao.h
// C Program header file for policy management
// By: Peter Talbott
// With assistance from Gemini and OpenAI
// April, May 2026


#ifndef POLICY_DAO_H
#define POLICY_DAO_H

#include <glib.h>
#include "gui.h" // Assuming AppContext is defined here

typedef struct {
    char *name;
    char *type;
    int risk;
} PolicyRecord;

typedef struct {
    AppContext *app;
    char *cmd;
    void (*callback)(PolicyRecord *p, gpointer data);
    gpointer user_data;
    PolicyRecord *result;
} GetPolicyArgs;

// Function Prototypes
PolicyRecord* get_policy_for_command(AppContext *app, const char *cmd);

gboolean set_command_policy(AppContext *app, PolicyRecord *p);
gboolean delete_command_policy(AppContext *app, const char *cmd);

GList* get_all_policies(AppContext *app);

void set_command_policy_async(AppContext *app, PolicyRecord *p, void (*callback)(gboolean, gpointer), gpointer user_data);
void free_policy_record(PolicyRecord *p);

#endif

