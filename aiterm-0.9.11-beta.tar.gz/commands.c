// part of aiterm project
// commands.c
// local command handler / registry / wrappers
// By: Peter Talbott
// Assisted by: Gemini
// June 2026, July 2026, August 2026

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <gtk/gtk.h>
#include <unistd.h>

#include "commands.h"
#include "ratelimit.h"
#include "gui.h"
#include "utils.h"
#include "update.h"
#include "help.h"
#include "gemini.h"
#include "gemini_cache.h"
#include "session_manager.h"
#include "session_manager_gui.h"
#include "history_manager_gui.h"
#include "policy_manager_gui.h"
#include "noise_filter_manager_gui.h"
#include "crypto.h"
#include "noisefilter.h"
#include "status.h"
#include "config.h"
#include "menu.h"
#include "snmp_manager.h"
#include "snmp_manager_gui.h"
#include "provider_manager_gui.h"
#include "autoexec.h"
#include "terminal.h"
#include "provider_keys.h"

extern const char* HIGHLIGHT_STRING;
extern const char* GENERAL_DIRECTIVES;

void cmd_close_provider_manager_wrapper(AppContext *app, const char *args) {
    if (app->manager.provider != NULL) {
        write_to_ai_pane(app, "System: ", "Closing AI Provider Manager window", "ai_tag", "cmd_tag");
        close_provider_manager(app);
    } else {
        write_to_ai_pane(app, "System: ", "AI Provider Manager window is not open", "ai_tag", "cmd_tag");
    }
}

// Parse command line options and handle early-exit CLI queries
void parse_command_line_options(AppContext *app, int argc, char *argv[]) {
    char *env_key = getenv("AITERM_MASTER_KEY");

    if (env_key) {
        app->security.master_key = strdup(env_key);
    }

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--debug") == 0) {
            print_version(app);
            app->sys.debug_mode = TRUE;
            app->sys.debug_mode_override = TRUE;
        } else if (strcmp(argv[i], "--version") == 0) {
            print_version(app);
            exit(0);
        } else if (strcmp(argv[i], "--color") == 0) {
	    app->sys.debug_color = TRUE;
        } else if (strcmp(argv[i], "--bw") == 0) {
	    app->sys.debug_color = FALSE;
        } else if (strcmp(argv[i], "--list-models") == 0) {
            load_config(app);
            print_version(app);
            if (!app->security.master_key) {
                printf("Error: no master key found!\n");
                exit(1);
            }
            char *models = gemini_list_models(app);
            printf("Gemini Model List:\n%s\n", models);
            if (app->security.master_key) {
                // Overwrite memory with zeros before freeing
                size_t len = strlen(app->security.master_key);
                memset(app->security.master_key, 0, len);
                free(app->security.master_key);
            }
            free_provider_config(&app->provider_config);
            g_free(app);
            exit(0);
        } else if (strcmp(argv[i], "--provider") == 0) {
            load_config(app);
            init_provider_config(app);
            print_version(app);
            char info[1024];
            snprintf(info, sizeof(info),
                     "Provider: %s\nModel: %s\nProtocol: %s\nBase URL: %s\nEndpoint: %s",
                     app->provider_config.provider ? app->provider_config.provider : "(none)",
                     app->provider_config.model ? app->provider_config.model : "(none)",
                     app->provider_config.kind == PROVIDER_KIND_GEMINI_GENERATE ?
                         "Gemini generateContent" : "OpenAI Chat Completions compatible",
                     app->provider_config.base_url ? app->provider_config.base_url : "(none)",
                     app->provider_config.endpoint ? app->provider_config.endpoint : "(none)");
            printf("%s\n", info);
            free_provider_config(&app->provider_config);
            exit(0);
        } else if (strcmp(argv[i], "--directives") == 0) {
            load_config(app);
            print_version(app);
            printf("\n%s\n", GENERAL_DIRECTIVES);
            exit(0);
        } else if (strcmp(argv[i], "--highlights") == 0) {
            load_config(app);
            print_version(app);
            printf("\n%s\n", HIGHLIGHT_STRING);
            exit(0);
        } else if (strcmp(argv[i], "--features") == 0) {
            printf("%s\n", get_features_text());
            exit(0);
        } else if (strcmp(argv[i], "--help") == 0) {
            print_version(app);
            printf("%s\n%s\n", get_cmd_help(), HIGHLIGHT_STRING);
            exit(0);
        // Added decrypt functionality 0.9.6-omega
        } else if (strcmp(argv[i], "--decrypt-pw") == 0) {
                if (!app->security.master_key) {
                fprintf(stderr, "Error: You must provide a master key (via --master or AITERM_MASTER_KEY) before encrypting.\n");
                exit(1);
            }
            print_version(app);
            load_config(app);

            char *lt_pl   = g_strdup(global_app->ansi.lt_purple);
            char *cy      = g_strdup(global_app->ansi.cyan);
            char *yl      = g_strdup(global_app->ansi.yellow);
            char *gr      = g_strdup(global_app->ansi.green);
            char *red     = g_strdup(global_app->ansi.red);
            char *nml     = g_strdup(global_app->ansi.normal);

	    app->sys.debug_mode = TRUE;            
            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sOPENAI_KEY:\t%s%s%s\n",
		lt_pl, nml, cy, nml, gr,
		red, app->security.openai_key ? app->security.openai_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sGEMINI_KEY:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
 		red, app->security.gemini_key ? app->security.gemini_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sGROQ_KEY:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
		red,  app->security.groq_key ? app->security.groq_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sOPENROUTER_KEY:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
		red,  app->security.openrouter_key ? app->security.openrouter_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sMISTRAL_KEY:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
		red,  app->security.mistral_key ? app->security.mistral_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sOLLAMA_KEY:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
		red,  app->security.ollama_key ? app->security.ollama_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sCUSTOM_KEY:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
		red, app->security.custom_key ? app->security.custom_key : "", nml);

            DEBUG_PRINT("[ %sDEBUG%s ]: [%sDecrypted%s] %sDB Password:\t%s%s%s\n",
                lt_pl, nml, cy, nml, gr,
		red, app->database.db_pass, nml);

	    g_free(lt_pl);
	    g_free(cy);
    	    g_free(yl);
    	    g_free(gr);
	    g_free(red);
	    g_free(nml);

            exit(0);
        } else if (strncmp(argv[i], "--master=", 9) == 0) {
            app->security.master_key = strdup(argv[i] + 9);
        } else if (strncmp(argv[i], "--crypt-pw=", 11) == 0) {
            if (!app->security.master_key) {
                fprintf(stderr, "Error: You must provide a master key (via --master or AITERM_MASTER_KEY) before encrypting.\n");
        	exit(1);
    	    }
            char *plaintext = argv[i] + 11;
            char *encrypted = crypt_to_hex(plaintext, app->security.master_key);
            print_version(app);
	    app->sys.debug_mode = TRUE;

            char *lt_pl   = g_strdup(global_app->ansi.lt_purple);
            char *cy      = g_strdup(global_app->ansi.cyan);
            char *yl      = g_strdup(global_app->ansi.yellow);
            char *gr      = g_strdup(global_app->ansi.green);
            char *red     = g_strdup(global_app->ansi.red);
            char *nml     = g_strdup(global_app->ansi.normal);

            if (encrypted) {
        	DEBUG_PRINT("Encrypted string: %s\n", encrypted);
        	free(encrypted);
            } else {
        	DEBUG_PRINT("Error: Encryption failed.\n");
            }

            g_free(lt_pl);
            g_free(cy);
            g_free(yl);
            g_free(gr);
            g_free(red);
            g_free(nml);

            exit(0);
       }
    }
    if (!app->security.master_key) {
	char *pwd = getpass("Enter Master Encryption Key: ");
	if (pwd) app->security.master_key = strdup(pwd);
    }
}

static CommandRegistry registry[] = {
    {"auto all", "Toggle (on/off/status): Tee, AutoReply, & AutoExecute", cmd_toggle_auto_all},
    {"autoreply", "Toggle real-time prompt analysis (on/off/status)", cmd_toggle_autoreply},
    {"autoretry", "Toggles auto AI retry (on/off/status)", cmd_toggle_autoretry},
    {"autoexe", "Toggle execution of AI payloads (on/off/status)", cmd_toggle_autoexe},
    {"clear", "Clear the contents of the AI pane", handle_clear_wrapper},
    {"close history manager", "Closes the history manager window", cmd_close_history_manager_wrapper},
    {"close noise manager", "Closes the noise filter manager window", cmd_close_noise_manager_wrapper},
    {"close provider manager", "Closes the AI provider manager window", cmd_close_provider_manager_wrapper},
    {"close policy manager", "Closes the policy manager window", cmd_close_policy_manager_wrapper},
    {"close session manager", "Closes the session manager window", cmd_close_session_manager_wrapper},
    {"close snmp manager", "Closes the snmp manager window", cmd_close_snmp_manager_wrapper},
    {"color", "Toggle colorized debug output text (on/off/status)", cmd_toggle_debug_color},
    {"command line help", "display all command line options", cmd_show_command_line_help_wrapper},
    {"debug", "Toggle debug mode out stderr (on/off/status)", cmd_toggle_debug},
    {"directives", "Display AI Directives", handle_directive_wrapper},
    {"extended help", "Display extended help message", handle_extended_help},
    {"features", "Display new aiterm features", handle_features_wrapper},
    {"help", "Display this dynamic help menu", handle_help_wrapper},
    {"history", "Display mysql history", handle_history_wrapper},
    {"hw", "Display various hardware info", handle_hw_wrapper},
    {"invalidate cache", "Force a reload of smart cache", cmd_invalidate_cache},
    {"list models", "Display all models from current provider", handle_list_models_wrapper},
    {"load config", "Loads configurations from aiterm.conf", handle_load_config_wrapper},
    {"noise filter", "Toggle noise filter (on/off/status)", cmd_toggle_noise_filter},
    {"noise add", "Add a pattern to the noise filter list", cmd_noise_add},
    {"noise delete", "Remove a pattern from the noise filter (TBA)", cmd_noise_delete},
    {"noise list", "List all active noise filter patterns (TBA)", cmd_noise_list},
    {"noise reload", "Reload noise filters from database", cmd_noisefilter_reload_wrapper},
    {"open history manager", "Open History Manager window", cmd_history_manager_wrapper},
    {"open noise manager", "Opens Noise Filter Manager window", cmd_noisefilter_manager_wrapper},
    {"open provider api keys", "Opens provider api key links window", provider_keys_show_wrapper},
    {"open provider manager", "Opens AI Provider Manager window", cmd_provider_manager_wrapper},
    {"open policy manager", "Open Policy Manager window", cmd_policy_manager_wrapper},
    {"open snmp manager", "Opens SNMP Target Manager window", cmd_snmp_manager_wrapper},
    {"open session manager", "Opens the session manager window", cmd_session_manager_wrapper},
    {"save config", "Saves configuration to aiterm.conf", handle_save_config_wrapper},
    {"session config", "Toggle loading config per session (on/off/status)", cmd_toggle_session_config},
    {"session default", "Sets current or specified UUID as default", cmd_session_default},
    {"session delete", "Deletes a session from the database", cmd_session_delete},
    {"session description", "Sets a desctiption to current session",  cmd_session_description},
    {"session list", "Lists sessions stored in database", cmd_session_list},
    {"session load", "Loads a previous session from database", cmd_session_load},
    {"session new", "Starts a new AI session", cmd_session_new},
    {"session no default", "Sets no session tto default", cmd_session_no_default},
    {"session read from global", "Toggle reading from global (on/off/status)", cmd_session_read_from_gloal_toggle},
    {"session show", "shows the current session uuid and description", cmd_session_show},
    {"session sync", "Sync all settings to current session table", cmd_session_sync},
    {"session write to global", "Toggle writing to global (on/off/status)", cmd_session_write_to_global_toggle},
    {"show queue", "Display queue of commands Auto Execute is waiting to perform", cmd_show_queue_wrapper},
    {"smart cache", "Smart Cache Toggle (on/off/status)", cmd_toggle_smart_cache},
    {"snmp cmd", "SNMP management: list, add, edit, delete, manager", handle_snmp_command},
    {"snmp dump", "Dump Raw SNMP data to AI pane", dump_raw_snmp_payload_to_ai_wrapper},
    {"snmp enable", "Toggle send SNMP payload to AI (on/off/status)", cmd_toggle_snmp_payload},
    {"snmp force", "Force flush SNMP payload to AI", cmd_force_snmp_flush}, 
    {"snmp poller", "SNMP Poller Service: start, stop, restart", handle_snmp_poller_command},
    {"snmp ticker", "Toggles SNMP Ticker (on/off/status)", cmd_toggle_snmp_ticker},
    {"provider", "Display AI provider [OpenAI/Gemini]", handle_provider_wrapper},
    {"ratelimit", "Toggle Raate Limiting (on/off/status)", cmd_toggle_ratelimit},
    {"reset db", "Reset database connection", cmd_reset_db_connect},
    {"reset state", "Reeset current AI state back to ready", handle_reset_state_wrapper},
    {"retry times", "Set the number of time to Autorety", cmd_set_retry_times}, 
    {"retry delay", "Set the delay between retries", cmd_set_retry_delay},
    {"rpm", "Set ratelimit Requests Per Minute", cmd_set_rpm},
    {"status", "Display operational metrics", handle_status_wrapper},
    {"tee", "Toggle immediate terminal capturing (on/off/status)", cmd_toggle_tee},
    {"version", "Display running aiterm version, build ID, and build time", handle_version_wrapper},
    {"xml tagging", "Toggle XML Tagging of AI payloads (on/off/status)", cmd_toggle_xml_tagging},
    {NULL, NULL, NULL} // Sentinel
};

gboolean execute_command(AppContext *app, const char *input) {
    // Trim optional leading slash
    const char *cmd = (input[0] == '/') ? input + 1 : input;
    for (int i = 0; registry[i].name != NULL; i++) {
        // Use strncasecmp for case-insensitive command matching
        if (strncasecmp(cmd, registry[i].name, strlen(registry[i].name)) == 0) {
            // Found it! Trigger the handler
            registry[i].handler(app, cmd + strlen(registry[i].name));
            return TRUE; // Command handled, signal AI thread to skip
        }
    }
    return FALSE; // No command found, pass to AI
}

void handle_snmp_poller_command(AppContext *app, const char *args) {
    const char *ptr = args;
    while (ptr && *ptr == ' ') ptr++; // Strip leading spaces

    if (!ptr || strlen(ptr) == 0 ) {
         write_to_ai_pane(app, "System: ", "Missing required command: (start/restart)\n", "ai_tag", "cmd_tag");
         return;
//    Removed due to very glitchy results 8/31/2026
//    } else if (strcmp(ptr, "stop") ==  0 || strcmp(ptr, "restart") == 0) {
//         if (app->SnmpContext.loop_running) {
//             write_to_ai_pane(app, "System: ", "Stopping SNMP Poller.\n", "ai_tag", "cmd_tag");
//             snmp_stop_poller(app);
//             sleep(50);
//         } else {
//             write_to_ai_pane(app, "System: ", "SNMP Poller not running.\n", "ai_tag", "cmd_tag");
//             return;
//         }
    } else if (strcmp(ptr, "start") == 0  || strcmp(ptr, "restart") == 0) {
         if (!app->SnmpContext.loop_running) {
             write_to_ai_pane(app, "System: ", "Starting SNMP Poller.\n", "ai_tag", "cmd_tag");
             init_snmp_subsystem(app);
             snmp_load_targets_from_db(app);
             snmp_start_poller(app);
         } else {
             write_to_ai_pane(app, "System: ", "SNMP Poller already running.\n", "ai_tag", "cmd_tag");
             return;
         }
    }
}

void handle_snmp_command(AppContext *app, const char *args) {
    const char *ptr = args;
    while (ptr && *ptr == ' ') ptr++; // Strip leading spaces

    if (!ptr || strlen(ptr) == 0 || strcmp(ptr, "list") == 0) {
        pthread_mutex_lock(&app->SnmpContext.lock);
        append_ai_text(app, "\n--- Active SNMP Targets ---\n", "ai_tag");
        for (guint i = 0; i < app->SnmpContext.total_targets; i++) {
            char *formatted = g_strdup_printf("[%d] ID:%d | %s (%s) | OID: %s | Value: %s\n",
                                  i, app->SnmpMetric[i].id,
                                  app->SnmpMetric[i].label, 
                                  app->SnmpMetric[i].ip_address,
                                  app->SnmpMetric[i].oid_str, 
                                  app->SnmpMetric[i].last_value[0] ? app->SnmpMetric[i].last_value : "N/A");
            append_ai_text(app, formatted, "ai_tag");
            g_free(formatted);
        }
        pthread_mutex_unlock(&app->SnmpContext.lock);
        return;
    }

    if (strncmp(ptr, "add ", 4) == 0) {
        char label[64], ip[64], community[64], oid_str[128];
        if (sscanf(ptr + 4, "%63s %63s %63s %127s", label, ip, community, oid_str) == 4) {
            pthread_mutex_lock(&app->access.db_mutex);
            char query[512];
            snprintf(query, sizeof(query),
                     "INSERT INTO snmp_targets (label, ip_address, community, oid_str, is_active) "
                     "VALUES ('%s', '%s', '%s', '%s', 1);",
                     label, ip, community, oid_str);
            
            if (mysql_query(app->database.global_db_conn, query) == 0) {
                append_ai_text(app, "[SNMP] Target inserted into DB. Reloading...\n", "ai_tag");
                pthread_mutex_unlock(&app->access.db_mutex);
                snmp_load_targets_from_db(app);
            } else {
                append_ai_text(app, "[SNMP] Failed to insert target into DB.\n", "ai_tag");
                pthread_mutex_unlock(&app->access.db_mutex);
            }
        } else {
            append_ai_text(app, "Usage: /snmp add <label> <ip> <community> <oid>\n", "ai_tag");
        }
        return;
    }

    if (strncmp(ptr, "edit ", 5) == 0) {
        int id = 0;
        char label[64], ip[64], community[64], oid_str[128];
        if (sscanf(ptr + 5, "%d %63s %63s %63s %127s", &id, label, ip, community, oid_str) == 5) {
            pthread_mutex_lock(&app->access.db_mutex);
            char query[512];
            snprintf(query, sizeof(query),
                     "UPDATE snmp_targets SET label='%s', ip_address='%s', community='%s', oid_str='%s' WHERE id=%d;",
                     label, ip, community, oid_str, id);
            
            if (mysql_query(app->database.global_db_conn, query) == 0) {
                append_ai_text(app, "[SNMP] Target updated in DB. Reloading...\n", "ai_tag");
                pthread_mutex_unlock(&app->access.db_mutex);
                snmp_load_targets_from_db(app);
            } else {
                append_ai_text(app, "[SNMP] Failed to update target in DB.\n", "ai_tag");
                pthread_mutex_unlock(&app->access.db_mutex);
            }
        } else {
            append_ai_text(app, "Usage: /snmp edit <id> <label> <ip> <community> <oid>\n", "ai_tag");
        }
        return;
    }

    if (strncmp(ptr, "delete ", 7) == 0 || strncmp(ptr, "del ", 4) == 0) {
        int id = 0;
        const char *id_ptr = (strncmp(ptr, "delete ", 7) == 0) ? ptr + 7 : ptr + 4;
        if (sscanf(id_ptr, "%d", &id) == 1) {
            pthread_mutex_lock(&app->access.db_mutex);
            char query[256];
            snprintf(query, sizeof(query), "DELETE FROM snmp_targets WHERE id=%d;", id);
            
            if (mysql_query(app->database.global_db_conn, query) == 0) {
                append_ai_text(app, "[SNMP] Target deleted from DB. Reloading...\n", "ai_tag");
                pthread_mutex_unlock(&app->access.db_mutex);
                snmp_load_targets_from_db(app);
            } else {
                append_ai_text(app, "[SNMP] Failed to delete target from DB.\n", "ai_tag");
                pthread_mutex_unlock(&app->access.db_mutex);
            }
        } else {
            append_ai_text(app, "Usage: /snmp delete <id>\n", "ai_tag");
        }
        return;
    }

    if (strcmp(ptr, "manager") == 0 || strcmp(ptr, "gui") == 0) {
        cmd_snmp_manager_wrapper(app, NULL);
        return;
    }
}

void dump_raw_snmp_payload_to_ai_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "Dump raw SNMP Payload:", "ai_tag", "cmd_tag");
    dump_raw_snmp_payload_to_ai(app);
}

void cmd_force_snmp_flush(AppContext *app, const char *args) {
    (void)args;
    if (!app) return;
    write_to_ai_pane(app, "System: ", "Forced SNMP payload flush", "ai_tag", "cmd_tag");
    pthread_mutex_lock(&app->SnmpContext.lock);
    app->SnmpContext.force_gemini_feed = TRUE;
    pthread_cond_signal(&app->SnmpContext.poller_cond);
    pthread_mutex_unlock(&app->SnmpContext.lock);
}

void cmd_snmp_manager_wrapper(AppContext *app, const char *args) {
    open_snmp_manager_window(app);
}

void cmd_close_snmp_manager_wrapper(AppContext *app, const char *args) {
    close_snmp_manager(app);
}

void cmd_show_queue_wrapper(AppContext *app, const char *args) {
    cmd_show_queue(app);
}

void provider_keys_show_wrapper(AppContext *app, const char *args) {
    provider_keys_show(app);
}

void display_dynamic_help(AppContext *app) {
    // 1. First, find the longest command name
    int max_len = 0;
    int current_len=0;
    for (int i = 0; registry[i].name != NULL; i++) {
        int len = strlen(registry[i].name);
        if (len > max_len) max_len = len;
    }

    // 2. Build the format string dynamically (e.g., "%-25s")
    //char format[32];
    //snprintf(format, sizeof(format), "%%-%ds : %%s\n", max_len + 2);

    GString *help = g_string_new("--- Available Commands ---\n");
    for (int i = 0; registry[i].name != NULL; i++) {
        current_len = strlen(registry[i].name);
	char *temp_name = g_strdup( (char *)registry[i].name);
        g_string_append_printf(help, "%s", temp_name);
       while(current_len < max_len+2) {
           current_len++;
           g_string_append_printf(help, ".");
       }
       g_string_append_printf(help, ": %s\n", registry[i].description);
       current_len=0;
    }

    write_to_ai_pane(app, "Help: ", help->str, "ai_tag", "body_tag");
    g_string_free(help, TRUE);
}

gboolean ui_display_list(gpointer data) {
    SessionListResult *res = (SessionListResult *)data;
    GList *iter = res->entries;
    while (iter != NULL) {
        SessionEntry *e = (SessionEntry *)iter->data;
        char *line = g_strdup_printf("%s : %s\n", e->uuid, e->description);
        write_to_ai_pane(global_app, "System: ", line, "ai_tag", "body_tag");
        g_free(line);
        // Clean up individual entry
        g_free(e->uuid);
        g_free(e->description);
        g_free(e);
        iter = iter->next;
    }
    g_list_free(res->entries);
    g_free(res);
    return FALSE; // Remove idle source
}

gboolean ui_display_show(gpointer data) {
    SessionShowResult *res = (SessionShowResult *)data;

    // 1. Prepare the content string
    char *desc = (res->description && strlen(res->description) > 0 && strcmp(res->description, "NULL") != 0) 
                 ? res->description
                 : "[No description set]";

    char *msg = g_strdup_printf("Session UUID: %s\nDescription: %s\n", res->uuid, desc);

    // 2. Render to the AI pane using the standard wrapper
    // This applies the "System: " prefix consistently
    write_to_ai_pane(global_app, "System: ", msg, "ai_tag", "body_tag");

    // 3. Cleanup
    g_free(msg);
    g_free(res->uuid);
    g_free(res->description);
    g_free(res);

    return FALSE; // Remove idle source
}

void cmd_invalidate_cache(AppContext *app, const char *args) {
    if (!app->sys.smart_cache_enabled) {
        write_to_ai_pane(app, "System: ", "Smart cache not enabled", "ai_tag", "cmd_tag");
        return;
    }

    // Force smartcace to be reloaded
    gemini_cache_invalidate(app);
    if (!app->gemini_cache.id) {
        write_to_ai_pane(app, "System: ", "Forced cache reload", "ai_tag", "cmd_tag");
    } else {
        write_to_ai_pane(app, "System: ", "Failed to force cache reload", "ai_tag", "cmd_tag");
    }
}

void cmd_session_sync(AppContext *app, const char *args) {
    session_sync_booleans_to_db(app);
    write_to_ai_pane(app, "System: ", "Synchronized settings with sesssion", "ai_tag", "cmd_tag");
}

void cmd_show_command_line_help_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "AITerm Command Line Help: ", get_cmd_help(), "ai_tag", "cmd_tag");
}

void cmd_reset_db_connect(AppContext *app, const char *args) {
    (void)args;
    if (!app) return;

    write_to_ai_pane_wrapper(app, "Attempting to reset Global Database connection.");

    /* Never re-initialize a live mutex.  Doing so while DB workers may hold or
     * wait on it is undefined behaviour and was a major source of intermittent
     * corruption.  Serialize the complete connection replacement instead. */
    pthread_mutex_lock(&app->access.db_mutex);

    if (app->database.global_db_conn) {
        mysql_close(app->database.global_db_conn);
        app->database.global_db_conn = NULL;
    }

    mysql_thread_init();
    int connected = init_remote_db(app);
    mysql_thread_end();

    pthread_mutex_unlock(&app->access.db_mutex);

    if (connected && app->database.global_db_conn) {
        write_to_ai_pane_wrapper(app, "Global Database connection re-established.");
        gemini_cache_invalidate(app);
    } else {
        write_to_ai_pane_wrapper(app, "Global Database connection reset failed.");
    }
}

void cmd_close_policy_manager_wrapper(AppContext *app, const char *args) {
    if(app->manager.policy != NULL) {
        write_to_ai_pane(app, "System: ", "Closing Policy Manager window", "ai_tag", "cmd_tag");
        close_policy_manager(app);
    } else {
        write_to_ai_pane(app, "System: ", "Policy Manager window is not open", "ai_tag", "cmd_tag");
    }
}

void cmd_close_history_manager_wrapper(AppContext *app, const char *args) {
    if(app->manager.history != NULL) {
        write_to_ai_pane(app, "System: ", "Closing History Manager window", "ai_tag", "cmd_tag");
        close_history_manager(app);
    } else {
        write_to_ai_pane(app, "System: ", "history Manager window is not open", "ai_tag", "cmd_tag");
    }
}

void cmd_close_session_manager_wrapper(AppContext *app, const char *args) {
    if(app->manager.session != NULL) {
        write_to_ai_pane(app, "System: ", "Closing Session Manager window", "ai_tag", "cmd_tag");
        close_session_manager(app);
    } else {
        write_to_ai_pane(app, "System: ", "Session Manager window is not open", "ai_tag", "cmd_tag");
    }
}

void cmd_close_noise_manager_wrapper(AppContext *app, const char *args) {
    if(app->manager.noise != NULL) {
        write_to_ai_pane(app, "System: ", "Closing noise Manager window", "ai_tag", "cmd_tag");
        close_noise_manager(app);
    } else {
        write_to_ai_pane(app, "System: ", "noise Manager window is not open", "ai_tag", "cmd_tag");
    }
}



// command helper wrappers
void handle_help_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "==== Available Functions ====", "system_tag", "body_tag");
    display_dynamic_help(app);
}

void handle_status_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "==== System status ====", "system_tag", "body_tag");
    display_status(app);
}

void handle_features_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "==== System features ====", "system_tag", "body_tag");
   // 1. If get_features() prints to stdout, we need to redirect it or capture it.
    // Better: Refactor get_features() to return a GString or char* instead of printing.

    char *feature_text = g_strdup(get_features_text()); // You should create this!

    if (feature_text) {
        write_to_ai_pane(app, "Features: ", feature_text, "system_tag", "body_tag");
        g_free(feature_text);
    } else {
        write_to_ai_pane(app, "Error: ", "Could not retrieve features.", "error_tag", "body_tag");
    }
}

void handle_clear_wrapper(AppContext *app, const char *args) {

    GtkTextBuffer *buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(app->gui.gemini_view));
    gtk_text_buffer_set_text(buf, "", -1);
}

void handle_provider_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "==== System provider ====", "system_tag", "body_tag");
    char info[512];
    snprintf(info, sizeof(info), "Provider: %s\nModel: %s", app->provider_config.provider, app->aiterm_runtime.model);
    write_to_ai_pane(app, "System: ", info, "cmd_tag", "cmd_tag");
}


void handle_directive_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "==== AI Directives ====", "system_tag", "body_tag");
    char info[1700];
    snprintf(info, sizeof(info), "\n%s\n", GENERAL_DIRECTIVES);
    write_to_ai_pane(app, "System: ", info, "cmd_tag", "cmd_tag");
}

void handle_list_models_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", gemini_list_models(app), "system_tag", "ai_tag");
    g_idle_add((GSourceFunc)scroll_ai_pane_to_bottom, app);
}

void handle_reset_state_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "AI State:", "Reset processing state", "system_tag", "ai_tag");
    if (g_atomic_int_get(&app->sys.is_processing)) {
        g_atomic_int_set(&app->sys.is_processing, 0);
        DEBUG_PRINT("[ DEBUG ]: RESET_STATE: cleared is_processing flag\n");
    }
    if (g_atomic_int_get(&app->sys.ai_busy)) {
        g_atomic_int_set(&app->sys.ai_busy, 0);
        DEBUG_PRINT("[ DEBUG ]: RESET_STATE: cleared ai_busy flag\n");
    }
    gemini_cache_invalidate(app);
}

void handle_hw_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "[ System Hardware ]\n", get_hw_stats(), "cmd_tag", "ai_tag");
}

void handle_history_wrapper(AppContext *app, const char *args) {
    display_all_history(app);
}

void handle_version_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", get_version_info(), "cmd_tag", "cmd_tag");
}

void handle_load_config_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "Loaded settings from configuration file", "system_tag", "ai_tag");
    load_config(app);
    init_provider_config(app);
    gemini_cache_invalidate(app);
}

void handle_save_config_wrapper(AppContext *app, const char *args) {
    write_to_ai_pane(app, "System: ", "Saved settings to configuration file", "system_tag", "ai_tag");
    save_config(app);
}

void cmd_session_new(AppContext *app, const char *args) {
    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_NEW;
    std->arg = g_strdup(args ? args : "No description"); // Use the user's description
    g_thread_new("session_new_worker", (GThreadFunc)session_db_worker, std);
    gemini_cache_invalidate(app);
}

void cmd_session_list(AppContext *app, const char *args) {
    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_LIST;
    // No args needed for list
    g_thread_new("session_list_worker", (GThreadFunc)session_db_worker, std);
}

void cmd_session_show(AppContext *app, const char *args) {
    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_SHOW;
    // We pass args as NULL since show doesn't require input,
    // but we ensure the struct pointer is safe.
    std->arg = NULL;

    g_thread_new("session_show_worker", (GThreadFunc)session_db_worker, std);
}

void cmd_session_description(AppContext *app, const char *args) {
    const char *ptr = args;
    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app, ": Error: Provide a description.");
        return;
    }
    // std->arg needs to be the text provided after "session description"
    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_DESCRIPTION;
    std->arg = g_strdup(ptr);
    g_thread_new("session_desc_worker", (GThreadFunc)session_db_worker, std);
}

void cmd_session_load(AppContext *app, const char *args) {
    const char *ptr = args;
    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) < 36) {
        write_to_ai_pane_wrapper(app, ": Error: Invalid UUID.");
        return;
    }

    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_LOAD;
    std->arg = g_strdup(ptr); // The UUID to load
    g_thread_new("session_load_worker", (GThreadFunc)session_db_worker, std);
    gemini_cache_invalidate(app);
}

void cmd_session_delete(AppContext *app, const char *args) {
    // 1. Skip the leading space
    const char *ptr = args;
    if (ptr && *ptr == ' ') {
        ptr++;
    }

    // 2. Validate that a UUID was provided (36 characters)
    if (!ptr || strlen(ptr) < 36) {
        write_to_ai_pane_wrapper(app, ": Error: You must provide a valid UUID to delete.");
        return;
    }

    // 3. Prevent deleting the currently active session
    if (strcmp(ptr, app->session.session_uuid) == 0) {
        write_to_ai_pane_wrapper(app, ": Error: Cannot delete the currently active session.");
        return;
    }

    // 4. Create the worker data
    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_DELETE;
    std->arg = g_strdup(ptr); // Copy the UUID

    g_thread_new("session_delete_worker", (GThreadFunc)session_db_worker, std);
}

void cmd_session_default(AppContext *app, const char *args) {
    const char *ptr = args;
    // Skip leading space if it exists
    if (ptr && *ptr == ' ') {
        ptr++;
    }

    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_DEFAULT;

    // Case 1: No args, use current session
    if (!ptr || strlen(ptr) == 0) {
        std->arg = g_strdup(app->session.session_uuid);
    }
    // Case 2: Provide specific UUID (36 chars)
    else if (strlen(ptr) >= 36) {
        std->arg = g_strdup(ptr);
    }
    else {
        write_to_ai_pane_wrapper(app, ": Error, invalid UUID.");
        g_free(std);
        return;
    }

    g_thread_new("session_default_worker", (GThreadFunc)session_db_worker, std);
}

void cmd_session_no_default(AppContext *app, const char *args) {
    SessionThreadData *std = g_malloc0(sizeof(SessionThreadData));
    std->app = app;
    std->type = CMD_SESSION_NO_DEFAULT;
    // No arg needed
    g_thread_new("session_no_default_worker", (GThreadFunc)session_db_worker, std);
    write_to_ai_pane(app, "System: ", "No default session set", "ai_tag", "cmd_tag");
}

void cmd_session_manager_wrapper(AppContext *app, const char *args) {
    DEBUG_PRINT("[ DEBUG ]: [Commands]: Opening Session Manager Window\n");
    write_to_ai_pane(app, "System: ", "Opening session manager window", "ai_tag", "cmd_tag");
    open_session_manager_window(app);
}

void cmd_history_manager_wrapper(AppContext *app, const char *args) {
    DEBUG_PRINT("[ DEBUG ]: [Commands]: Opening History Manager Window\n");
    write_to_ai_pane(app, "System: ", "Opening history manager window", "ai_tag", "cmd_tag");
    open_history_manager_window(app);
}

void cmd_noisefilter_manager_wrapper(AppContext *app, const char *args) {
    DEBUG_PRINT("[ DEBUG ]: [Commands]: Opening Noise Filter Manager Window\n");
    noise_filter_load_from_db(app);
    write_to_ai_pane(app, "System: ", "Opening noise filter manager window", "ai_tag", "cmd_tag");
    open_noise_filter_manager_window(app);
}

void cmd_provider_manager_wrapper(AppContext *app, const char *args) {
    DEBUG_PRINT("[ DEBUG ]: [Commands]: Opening AI Provider Manager Window\n");
    write_to_ai_pane(app, "System: ", "Opening AI Provider Manager window", "ai_tag", "cmd_tag");
    open_provider_manager_window(app);
}

void cmd_policy_manager_wrapper(AppContext *app, const char *args) {
    DEBUG_PRINT("[ DEBUG ]: [Commands]: Opening Policy Manager Window\n");
    write_to_ai_pane(app, "System: ", "Opening policy manager window", "ai_tag", "cmd_tag");
    open_policy_manager_window(app);
}

// -------------------------------
// Commands setting integer values
// -------------------------------
void cmd_set_rpm(AppContext *app, const char *args) {
    const char *ptr = args;

    // 1. Skip any initial spaces after the command name (e.g., "/rpm 6" or "/rpm =6")
    while (ptr && *ptr == ' ') {
        ptr++;
    }

    // 2. If an equals sign is present, skip past it (e.g., "/rpm=6" or "/rpm =6")
    if (ptr && *ptr == '=') {
        ptr++;
    }

    // 3. Skip any spaces after the equals sign just in case (e.g., "/rpm = 6")
    while (ptr && *ptr == ' ') {
        ptr++;
    }

    // 4. Validation guard: Ensure we actually have characters left to parse
    if (!ptr || strlen(ptr) == 0 || !isdigit((unsigned char)*ptr)) {
        write_to_ai_pane_wrapper(app, ": Error: Required parameter missing or invalid. Provide a numeric RPM value.");
        return;
    }

    // 5. Safely convert the sanitized string to an integer
    app->limiter.requests_per_minute = atoi(ptr);
    DEBUG_PRINT("[ DEBUG ]: Ratelimit: Requests Per Minute set to %d (Parsed from raw input)\n", 
                app->limiter.requests_per_minute);

    // Re-initialize the rate limiter state with the newly validated RPM
    ratelimit_init(&app->limiter, app->limiter.requests_per_minute);

    GString *status_report = g_string_new(": Requests per minute is set to");
    char *rpm_val = g_malloc(8);
    snprintf(rpm_val, 8, "%d", app->limiter.requests_per_minute);
    g_string_append_printf(status_report, ":\t%s\n", rpm_val);

    write_to_ai_pane_wrapper(app, status_report->str);
    g_string_free(status_report, TRUE);
}

void cmd_set_retry_times(AppContext *app, const char *args) {
    const char *ptr = args;

    // 1. Skip any initial spaces after the command name (e.g., "/rpm 6" or "/rpm =6")
    while (ptr && *ptr == ' ') {
        ptr++;
    }

    // 2. If an equals sign is present, skip past it (e.g., "/rpm=6" or "/rpm =6")
    if (ptr && *ptr == '=') {
        ptr++;
    }

    // 3. Skip any spaces after the equals sign just in case (e.g., "/rpm = 6")
    while (ptr && *ptr == ' ') {
        ptr++;
    }

    // 4. Validation guard: Ensure we actually have characters left to parse
    if (!ptr || strlen(ptr) == 0 || !isdigit((unsigned char)*ptr)) {
        write_to_ai_pane_wrapper(app, ": Error: Required parameter missing or invalid. Provide a numeric RPM value.");
        return;
    }

    // 5. Safely convert the sanitized string to an integer
    app->retry_config.max_retries = atoi(ptr);
    DEBUG_PRINT("[ DEBUG ]: [AutoRetry] Maximum retries set to %d (Parsed from raw input)\n", 
                app->retry_config.max_retries);

    GString *status_report = g_string_new(": Maximum retries is set to");
    char *max_retries_val = g_malloc(8);
    snprintf(max_retries_val, 8, "%d", app->retry_config.max_retries);
    g_string_append_printf(status_report, ":\t%s\n", max_retries_val);

    write_to_ai_pane_wrapper(app, status_report->str);
    g_string_free(status_report, TRUE);

}

void cmd_set_retry_delay(AppContext *app, const char *args) {
    const char *ptr = args;

    // 1. Skip any initial spaces after the command name (e.g., "/rpm 6" or "/rpm =6")
    while (ptr && *ptr == ' ') {
        ptr++;
    }

    // 2. If an equals sign is present, skip past it (e.g., "/rpm=6" or "/rpm =6")
    if (ptr && *ptr == '=') {
        ptr++;
    }

    // 3. Skip any spaces after the equals sign just in case (e.g., "/rpm = 6")
    while (ptr && *ptr == ' ') {
        ptr++;
    }

    // 4. Validation guard: Ensure we actually have characters left to parse
    if (!ptr || strlen(ptr) == 0 || !isdigit((unsigned char)*ptr)) {
        write_to_ai_pane_wrapper(app, ": Error: Required parameter missing or invalid. Provide a numeric value.");

        return;
    }

    // 5. Safely convert the sanitized string to an integer
    app->retry_config.delay_sec = atoi(ptr);
    DEBUG_PRINT("[ DEBUG ]: [AutoRetry] Delay set to %d seconds (Parsed from raw input)\n",
                app->retry_config.delay_sec);

    GString *status_report = g_string_new(": AutoReply delay is set to");
    char *delay_sec_val = g_malloc(8);
    snprintf(delay_sec_val, 8, "%d", app->retry_config.delay_sec);
    g_string_append_printf(status_report, ":\t%s seconds\n", delay_sec_val);

    write_to_ai_pane_wrapper(app, status_report->str);
    g_string_free(status_report, TRUE);

}


// ================= Start of Toggle ON / OFF / STATUS functions  ======================
void cmd_toggle_session_config(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        write_to_ai_pane_wrapper(app, app->sys.load_from_session ? ": Session based config Enabled" : ": Session based config Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }
    //gboolean state = (strstr(ptr, "on") != NULL);
    app->sys.load_from_session = state;
    write_to_ai_pane_wrapper(app, app->sys.load_from_session ? ": Session based config Enabled" : ": Session based config Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_snmp_payload(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        write_to_ai_pane_wrapper(app, app->SnmpContext.enable_gemini_feed ? ": Send SNMP Payloads Enabled" : ": Send SNMP Payloads Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }
    //gboolean state = (strstr(ptr, "on") != NULL);
    app->SnmpContext.enable_gemini_feed = state;
    write_to_ai_pane_wrapper(app, app->SnmpContext.enable_gemini_feed ? ": Send SNMP Payloads Enabled" : ": Send SNMP Payloads Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_snmp_ticker(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.snmp_ticker_enabled;
        write_to_ai_pane_wrapper(app, state ? ": SNMP Ticker Enabled" : ": SNMP Ticker Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }
    //gboolean state = (strstr(ptr, "on") != NULL);
    app->sys.snmp_ticker_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": SNMP Ticker Enabled" : ": SNMP Ticker Disabled");
    if (app->sys.snmp_ticker_enabled) {
        app->gui.snmp_ticker_timer_id =
        g_timeout_add(150, update_snmp_ticker_scroll, app);
    } else {
        app->gui.snmp_ticker_timer_id = 0;
    }
    sync_toggle_ui_elements(app);
}

void cmd_toggle_auto_all(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
	state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        write_to_ai_pane_wrapper(app, app->sys.tee_enabled ?          ": Tee Collection Enabled" : ": Tee Collection Disabled");
        write_to_ai_pane_wrapper(app, app->sys.autoreply_enabled ?    ": Auto Reply Enabled"     : ": Auto Reply Disabled");
        write_to_ai_pane_wrapper(app, app->sys.auto_execute_enabled ? ": Auto Execute Enabled"   : ": Auto Execute Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }
    //gboolean state = (strstr(ptr, "on") != NULL);
    app->sys.tee_enabled = state;
    app->sys.autoreply_enabled = state;
    app->sys.auto_execute_enabled = state;
    write_to_ai_pane_wrapper(app, app->sys.tee_enabled ?          ": Tee Collection Enabled" : ": Tee Collection Disabled");
    write_to_ai_pane_wrapper(app, app->sys.autoreply_enabled ?    ": Auto Reply Enabled"     : ": Auto Reply Disabled");
    write_to_ai_pane_wrapper(app, app->sys.auto_execute_enabled ? ": Auto Execute Enabled"   : ": Auto Execute Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_debug(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        write_to_ai_pane_wrapper(app, app->sys.debug_mode ? ": Debug Mode Enabled" : ": Debug Mode Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }
    //gboolean state = (strstr(ptr, "on") != NULL);
    app->sys.debug_mode = state;
    write_to_ai_pane_wrapper(app, app->sys.debug_mode ? ": Debug Mode Enabled" : ": Debug Mode Disabled");
    sync_toggle_ui_elements(app);
}


void cmd_session_read_from_gloal_toggle(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->session.read_from_global;
        write_to_ai_pane_wrapper(app, state ? ": Reading from GLOBAL history." : ": Reading STRICT history.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->session.read_from_global = state;
    write_to_ai_pane_wrapper(app, state ? ": Reading from GLOBAL history." : ": Reading STRICT history.");
    sync_toggle_ui_elements(app);
}

void cmd_session_write_to_global_toggle(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->session.write_to_global;
        write_to_ai_pane_wrapper(app, state ? ": Writing to GLOBAL session." : ": Writing to STRICT session.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->session.write_to_global = state;
    write_to_ai_pane_wrapper(app, state ? ": Writing to GLOBAL session." : ": Writing to STRICT session.");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_tee(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.tee_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Tee Collection Enabled" : ": Tee Collection Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.tee_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Tee Collection Enabled" : ": Tee Collection Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_autoreply(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.autoreply_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Auto Reply Enabled" : ": Auto Reply Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.autoreply_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Auto Reply Enabled" : ": Auto Reply Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_autoretry(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->retry_config.is_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Auto Retry Enabled" : ": Auto Retry Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->retry_config.is_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Auto Retry Enabled" : ": Auto Retry Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_autoexe(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.auto_execute_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Auto Execute Enabled" : ": Auto Execute Disabled");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.auto_execute_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Auto Execute Enabled" : ": Auto Execute Disabled");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_ratelimit(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.ratelimit_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Rate Limiting Enabled." : ": Rate Limiting Disabled.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.ratelimit_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Rate Limiting Enabled." : ": Rate Limiting Disabled.");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_smart_cache(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.smart_cache_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Smart Cache Enabled." : ": Smart Cache Disabled.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.smart_cache_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Smart Cache Enabled." : ": Smart Cache Disabled.");
    sync_toggle_ui_elements(app);
}

void cmd_toggle_noise_filter(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.noise_filter_enabled;
        write_to_ai_pane_wrapper(app, state ? ": Noise Block Enabled." : ": Noise Block Disabled.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.noise_filter_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": Noise Block Enabled." : ": Noise Block Disabled.");
    sync_toggle_ui_elements(app);
    noise_filter_load_from_db(app);
}

void cmd_toggle_xml_tagging(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->xml.tagging_enabled;
        write_to_ai_pane_wrapper(app, state ? ": XML Payload Tagging Enabled." : ": XML Payload Tagging Disabled.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->xml.tagging_enabled = state;
    write_to_ai_pane_wrapper(app, state ? ": XML Payload Tagging Enabled." : ": XML Payload Tagging Disabled.");
    sync_toggle_ui_elements(app);
    noise_filter_load_from_db(app);
}

void cmd_toggle_debug_color(AppContext *app, const char *args) {
    const char *ptr = args;
    gboolean state = FALSE;

    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app,": Required parameter missing: ON, OFF, or STATUS");
        return;
    }

    if (strcmp(ptr, "on") == 0) {
        state = TRUE;
    } else if (strcmp(ptr, "off") == 0) {
        state = FALSE;
    } else if (strcmp(ptr, "status") == 0) {
        state = app->sys.debug_color;
        write_to_ai_pane_wrapper(app, state ? ": Colorized debug text Enabled." : ": Colorized debug text Disabled.");
        sync_toggle_ui_elements(app);
        return;
    } else {
        GString *msg = g_string_new(": Unknown parameter parsed: ");
        g_string_append_printf(msg, "%s ", ptr);
        write_to_ai_pane_wrapper(app, msg->str);
        return;
    }

    app->sys.debug_color = state;
    write_to_ai_pane_wrapper(app, state ? ": Colorized debug text Enabled." : ": Colorized debug text Disabled.");
    init_colors(app);
    sync_toggle_ui_elements(app);
}

// ================= End of Toggle ON / OFF functions  ======================

void handle_extended_help(AppContext *app, const char *args) {
    write_to_ai_pane(app, "[ Extended Help System ]\n", get_help_text(), "cmd_tag", "cmd_tag");
}

void cmd_noise_add(AppContext *app, const char *args) {
    const char *ptr = args;

    // Skip the leading separator space if it exists
    if (ptr && *ptr == ' ') {
        ptr++;
    }

    if (!ptr || strlen(ptr) == 0) {
        write_to_ai_pane_wrapper(app, ": Error: You must provide a text pattern to filter.");
        return;
    }

    // Invoke our database/cache entry function
    noise_filter_add(app, ptr);

    char *msg = g_strdup_printf(": Success: Pattern '%s' added to noise filters.", ptr);
    write_to_ai_pane_wrapper(app, msg);
    noise_filter_load_from_db(app);
    g_free(msg);
}

void cmd_noise_list(AppContext *app, const char *args) {
    // We ignore 'args' because listing doesn't require extra parameters
    noise_filter_list(app);
}

void cmd_noise_delete(AppContext *app, const char *args) {
    // Placeholder stub until announced
    write_to_ai_pane_wrapper(app, ": System: 'noise delete' function is to be announced as of yet.");
    noise_filter_load_from_db(app);
}

void cmd_noisefilter_reload_wrapper(AppContext *app, const char *args) {
    noise_filter_load_from_db(app);
    write_to_ai_pane(app, "System: ", "Reloaded noise filters from database into running cache", "ai_tag", "cmd_tag");
}

void dispatch_command_to_pane(AppContext *app, int target_pane_id, const char *cmd) {
    if (!app || !cmd) return;

    GtkWidget *term_widget = NULL;

    if (app->gui.notebook && target_pane_id >= 0) {
        term_widget = gtk_notebook_get_nth_page(GTK_NOTEBOOK(app->gui.notebook), target_pane_id);
    }

    if (!term_widget) {
        term_widget = app->ui.vterm ? app->ui.vterm : app->gui.terminal_view;
    }

    if (term_widget && VTE_IS_TERMINAL(term_widget)) {
        vte_terminal_feed_child(VTE_TERMINAL(term_widget), cmd, -1);
        vte_terminal_feed_child(VTE_TERMINAL(term_widget), "\n", 1);
    }
}

