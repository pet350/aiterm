// part of aiterm project
// status.c
// Display status utility used in this project
// By: Peter Talbott
// Assisted by: Gemini
// May 2026

#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <json-c/json.h>
#include <vte/vte.h>
#include <mariadb/mysql.h>

#include "utils.h"
#include "gui.h"
#include "openai.h"
#include "crypto.h" // Add this include
#include "update.h"
#include "tee_handler.h"
#include "ratelimit.h"
#include "status.h"

// updated 0.8.3 send status to AI as well as display it
// modified 0.8.4 display status in color
void display_status(AppContext *app) {
    // Lock the database mutex to ensure thread-safety during the status check
    mysql_thread_init();

    pthread_mutex_lock(&app->access.db_mutex);
    DEBUG_PRINT("[ DEBUG ]: [STATUS] Locked DB Mutex.\n");

    gboolean is_connected = FALSE;
    int ping_res = -1;

    DEBUG_PRINT("[ DEBUG ]: [STATUS] Checking database connection status...\n");
    DEBUG_PRINT("[ DEBUG ]: [STATUS] app->database.global_db_conn pointer value: %p\n", (void*)app->database.global_db_conn);

    if (app->database.global_db_conn != NULL) {
        // mysql_ping returns 0 if the connection is alive
        ping_res = mysql_ping(app->database.global_db_conn);
        DEBUG_PRINT("[ DEBUG ]: [STATUS] mysql_ping returned: %d\n", ping_res);
        if (ping_res == 0) {
            is_connected = TRUE;
        } else {
            DEBUG_PRINT("[ DEBUG ]: [STATUS] mysql_ping failed error: %s\n", mysql_error(app->database.global_db_conn));
        }
    }

    // 1. Build a single raw string containing the whole status report for the AI
    GString *status_report = g_string_new("--- SYSTEM STATUS ---\n");

    const char *tee_val = app->sys.tee_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Tee Logging:\t%s\n", tee_val);

    const char *auto_val = app->sys.autoreply_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Autoreply:\t%s\n", auto_val);

    const char *autoretry_val = app->retry_config.is_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Autoretry:\t%s\n", autoretry_val);

    const char *auto_exec_val = app->sys.auto_execute_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Auto Execute:\t%s\n", auto_exec_val);

    const char *ratelimit_val = app->sys.ratelimit_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Rate Limit Enabled:\t%s\n", ratelimit_val);

    const char *smart_cache_val = app->sys.smart_cache_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Smart Cache Enabled:\t%s\n", smart_cache_val);

    const char *noise_filter_val = app->sys.noise_filter_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "Noise Filter Enabled:\t%s\n", noise_filter_val);

    const char *snmp_enable_gemini_feed_val = app->SnmpContext.enable_gemini_feed ? "ON" : "OFF";
    g_string_append_printf(status_report, "SNMP Gemini Feed Enabled:\t%s\n", snmp_enable_gemini_feed_val);

    const char *snmp_ticker_enabled_val = app->sys.snmp_ticker_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "SNMP Ticker Enabled:\t%s\n", snmp_ticker_enabled_val);

    const char *SnmpContext_loop_running_val = app->SnmpContext.loop_running ? "Yes" : "No";
    g_string_append_printf(status_report, "SNMP Loop Running:\t%s\n", SnmpContext_loop_running_val);
    
    char *snmp_poll_interval_val =  g_malloc(8);
    snprintf(snmp_poll_interval_val, 8, "%d", app->SnmpContext.poll_interval_sec);
    g_string_append_printf(status_report, "SNMP Poll Interval:\t%s\n", snmp_poll_interval_val);

    const char *debug_mode_val = app->sys.debug_mode ? "ON" : "OFF";
    g_string_append_printf(status_report, "Debug Mode Enabled:\t%s\n", debug_mode_val);

    const char *debug_color_val = app->sys.debug_color ? "ON" : "OFF";
    g_string_append_printf(status_report, "Debug ANSI Color:\t%s\n", debug_color_val);

    const char *xml_tagging_val = app->xml.tagging_enabled ? "ON" : "OFF";
    g_string_append_printf(status_report, "XML Payload Tagging Enabled:\t%s\n", xml_tagging_val);

    const char *load_from_session_val = app->sys.load_from_session ? "ON" : "OFF";
    g_string_append_printf(status_report, "Session based config Enabled:\t%s\n", load_from_session_val);

    char *rpm_val = g_malloc(8);
    snprintf(rpm_val, 8, "%d", app->limiter.requests_per_minute);
    g_string_append_printf(status_report, "Requests Per Minute:\t%s\n", rpm_val);

    char *max_retries_val = g_malloc(8);
    snprintf(max_retries_val, 8, "%d", app->retry_config.max_retries);
    g_string_append_printf(status_report, "AutoRetry Times:\t%s\n", max_retries_val);

    char *delay_sec_val = g_malloc(8);
    snprintf(delay_sec_val, 8, "%d", app->retry_config.delay_sec);
    g_string_append_printf(status_report, "AutoRetry Delay:\t%s\n", delay_sec_val);

    const char *write_to_global_val = app->session.write_to_global ? "GLOBAL session" : "STRICT session";
    g_string_append_printf(status_report, "Writting to database:\t%s\n", write_to_global_val);

    const char *read_from_global_val = app->session.read_from_global ? "GLOBAL session" : "STRICT session";
    g_string_append_printf(status_report, "Reading from database:\t%s\n", read_from_global_val);

    int db_ok = (app->database.global_db_conn && mysql_ping(app->database.global_db_conn) == 0);
    g_string_append_printf(status_report, "Database:\t%s\n", db_ok ? "CONNECTED" : "DISCONNECTED");

    const char *mysql_ping_val = is_connected ? "ON" : "OFF";
    g_string_append_printf(status_report, "MariaDB Ping Results:\t%s\n", mysql_ping_val);

    const char *active_api_key = get_provider_api_key(app, app->provider_config.provider);
    int ai_ok = (active_api_key && strlen(active_api_key) > 0);
    g_string_append_printf(status_report, "AI Status:\t%s\n", ai_ok ? "READY" : "MISSING CONFIG");

    g_string_append_printf(status_report, "Session UUID:\t%s\n", app->session.session_uuid ? app->session.session_uuid : "N/A");
    g_string_append(status_report, "---------------------");

    pthread_mutex_unlock(&app->access.db_mutex);
    DEBUG_PRINT("[ DEBUG ]: [STATUS] Unlocked DB Mutex.\n");

    // 2. Display to the User in the AI Pane with granular coloring
    append_ai_text(app, "[ Local Status ]\n", "cmd_tag");
    append_ai_text(app, "--- SYSTEM STATUS ---\n", "body_tag");

    // Tee Logging Row
    append_ai_text(app, "Tee Logging:\t\t", "body_tag");
    append_ai_text(app, tee_val, app->sys.tee_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Autoreply Row
    append_ai_text(app, "Autoreply:\t\t", "body_tag");
    append_ai_text(app, auto_val, app->sys.autoreply_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Autoretry Row
    append_ai_text(app, "Autoretry:\t\t", "body_tag");
    append_ai_text(app, autoretry_val, app->retry_config.is_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Auto Execute Row
    append_ai_text(app, "Auto Execute:\t\t", "body_tag");
    append_ai_text(app, auto_exec_val, app->sys.auto_execute_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Ratelimit Row
    append_ai_text(app, "Ratelimit:\t\t", "body_tag");
    append_ai_text(app, ratelimit_val, app->sys.ratelimit_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Smart Cache Row
    append_ai_text(app, "Smart Cache:\t\t", "body_tag");
    append_ai_text(app, smart_cache_val, app->sys.smart_cache_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Noise Filter Row
    append_ai_text(app, "Noise Filter:\t\t", "body_tag");
    append_ai_text(app, noise_filter_val, app->sys.noise_filter_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // SNMP Feed Row
    append_ai_text(app, "SNMP Feed Enabled:\t", "body_tag");
    append_ai_text(app, snmp_enable_gemini_feed_val, app->SnmpContext.enable_gemini_feed ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // SNMP Ticker Enabled Row
    append_ai_text(app, "SNMP Ticker Enabled:\t", "body_tag");
    append_ai_text(app, snmp_ticker_enabled_val, app->sys.snmp_ticker_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // SNMP Loop Running Row
    append_ai_text(app, "SNMP Loop Running:\t", "body_tag");
    append_ai_text(app, SnmpContext_loop_running_val, app->SnmpContext.loop_running ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");
    
    // SNMP Poll Interval Row
    append_ai_text(app, "SNMP Poll Interval:\t", "body_tag");
    append_ai_text(app, snmp_poll_interval_val, "ai_tag");
    append_ai_text(app, "\n", "body_tag");

    // Requests Per Minute
    append_ai_text(app, "Requests Per Minute:\t", "body_tag");
    append_ai_text(app, rpm_val, "ai_tag");
    append_ai_text(app, "\n", "body_tag");

    // Auto retry times
    append_ai_text(app, "AutoRetry Times:\t", "body_tag");
    append_ai_text(app, max_retries_val, "ai_tag");
    append_ai_text(app, "\n", "body_tag");

    // Auto retry delay
    append_ai_text(app, "AutoRetry Delay:\t", "body_tag");
    append_ai_text(app, delay_sec_val, "ai_tag");
    append_ai_text(app, "\n", "body_tag");

    // Debug Enabled Row
    append_ai_text(app, "Debug Mode:\t\t", "body_tag");
    append_ai_text(app, debug_mode_val, app->sys.debug_mode ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Debug Color Row
    append_ai_text(app, "Debug Color Text:\t", "body_tag");
    append_ai_text(app, debug_color_val, app->sys.debug_color ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Noise Filter Row
    append_ai_text(app, "XML Payload Tagging:\t", "body_tag");
    append_ai_text(app, xml_tagging_val, app->xml.tagging_enabled ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Session Based Config Row
    append_ai_text(app, "Session Based Config:\t", "body_tag");
    append_ai_text(app, load_from_session_val, app->sys.load_from_session ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Database Writting
    append_ai_text(app, "Write to database:\t", "body_tag");
    append_ai_text(app, write_to_global_val, app->session.write_to_global ? "cmd_tag" : "ai_tag");
    append_ai_text(app, "\n", "body_tag");

    // Database Reading
    append_ai_text(app, "Read from database:\t", "body_tag");
    append_ai_text(app, read_from_global_val, app->session.read_from_global ? "cmd_tag" : "ai_tag");
    append_ai_text(app, "\n", "body_tag");

    // mysql ping rresults
    append_ai_text(app, "MYSQL Server:\t\t", "body_tag");
    append_ai_text(app, is_connected ? "ALIVE" : "DEAD", is_connected ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Database Row
    append_ai_text(app, "Database:\t\t", "body_tag");
    append_ai_text(app, db_ok ? "CONNECTED" : "DISCONNECTED", db_ok ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // AI Status Row
    append_ai_text(app, "AI Status:\t\t", "body_tag");
    append_ai_text(app, ai_ok ? "READY" : "MISSING CONFIG", ai_ok ? "ai_tag" : "cmd_tag");
    append_ai_text(app, "\n", "body_tag");

    // Session UUID Row
    append_ai_text(app, "Session UUID:\t\t", "body_tag");
    append_ai_text(app, app->session.session_uuid, "ai_tag");
    append_ai_text(app, "\n---------------------\n\n", "body_tag");

    // 3. Send the raw un-tagged plain text block to the AI history
    if (app->sys.tee_enabled) {
        tee_handle_output(app, status_report->str);
        tee_handle_output(app, "\n");
        tee_flush_timed(app);
    }

    // Cleanup
    g_string_free(status_report, TRUE);
    mysql_thread_end();
}
